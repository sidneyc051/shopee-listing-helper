# agent_pipeline.py
import os
import json
from pathlib import Path
from typing import Dict
from PIL import Image
from google import genai
from google.genai import types

from models import BatchGroupingResult, ImageGroup, ShopeeListingSchema
from chart_generator import generate_size_chart_image

client = genai.Client()  # 自動讀取環境變數 GEMINI_API_KEY
MODEL_ID = "gemini-2.5-flash"


def step1_group_and_extract(image_dir: str, user_notes: Dict[str, str]) -> BatchGroupingResult:
    """
    第一階段：將混雜的多張商品照片自動歸類分群，並進行銘牌 OCR（型號、BSMI、外觀特徵）
    """
    contents = []
    image_files = sorted([
        f for f in os.listdir(image_dir)
        if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
    ])

    if not image_files:
        raise ValueError(f"在 {image_dir} 中找不到任何圖片檔案。")

    for fname in image_files:
        img_path = os.path.join(image_dir, fname)
        img = Image.open(img_path)
        note = user_notes.get(fname, "無特別備註")
        contents.append(f"【圖片檔名: {fname} | 賣家備註: {note}】")
        contents.append(img)

    prompt = """
    你是一位專業的台灣電商上架視覺分析 Agent。
    請檢視以上所有上傳的照片與檔名，執行以下任務：
    1. 視覺分群：判斷哪些照片屬於「同一個商品」（例如正面照、背面照、機身貼紙照、外盒照），將它們歸類為同一個 group_id（如 item_01, item_02）。
    2. 銘牌與標籤提取：仔細讀取照片中的文字、型號（例如 IPM850、EH-NA57 等）、規格（如 38mm、雙電壓）、以及是否有直接印出台灣 BSMI 檢驗字號（通常為 R、M、T 開頭加上 5 碼英數字）。
    3. 結合賣家備註，詳細記錄外觀特徵與新舊狀況。
    """
    contents.append(prompt)

    response = client.models.generate_content(
        model=MODEL_ID,
        contents=contents,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=BatchGroupingResult,
            temperature=0.1,
        ),
    )
    return BatchGroupingResult.model_validate_json(response.text)


def step2_research_and_build_json(
    group: ImageGroup,
    image_dir: str,
    general_note: str = ""
) -> ShopeeListingSchema:
    """
    第二階段：針對單一商品群組，啟動 Google Search 聯網查價（全新/二手）、查長寬高、適用年齡與 BSMI，並產出蝦皮 JSON
    """
    contents = []
    for fname in group.image_filenames:
        img_path = os.path.join(image_dir, fname)
        contents.append(Image.open(img_path))

    research_prompt = f"""
    請根據這組商品的照片與第一階段視覺提取結果，使用 Google Search 搜尋台灣市場資料，並整理成蝦皮賣家中心上架格式：

    【第一階段提取資訊】
    - 群組編號：{group.group_id}
    - 圖片清單：{group.image_filenames}
    - 辨識品牌：{group.detected_brand}
    - 辨識型號：{group.detected_model}
    - 照片上的 BSMI：{group.detected_bsmi_from_photo}
    - 外觀與特徵：{group.visual_features}
    - 賣家補充說明：{general_note}

    【聯網檢索與填表任務】
    1. 查全新與二手價格（台幣）：
       - 搜尋台灣電商（Momo、PChome、官方商城）該型號的「全新品售價」。
       - 搜尋蝦皮拍賣、旋轉拍賣上該型號「二手 / 九成新 / 出清」的實際成交或掛牌價格區間（請排除低於新品價 1 折的單賣配件或故障品價格），並計算出三個檔位的建議售價。
    2. 查尺寸（長寬高）與適用年齡：
       - 搜尋該商品的官方尺寸（長、寬、高 cm 與重量 kg），並判斷是否符合台灣超商取貨規範（最長邊小於等於 45cm，三邊總和小於等於 105cm，重量小於等於 5kg）。
       - 若為童鞋、童裝、玩具或婦幼用品，請查出或推算適用年齡與尺碼範圍。
    3. 查 BSMI 字號：
       - 若照片已拍到 BSMI 字號則直接採用；若未拍到且商品屬於家電、美髮器、3C 或玩具，請務必以「{group.detected_brand} {group.detected_model} BSMI」搜尋台灣電商頁面或標檢局公開資訊，填入正確的 R/M/T 字號。
    4. 尺寸表資料：
       - 若商品屬於衣服、鞋子、拖鞋等蝦皮強制要求尺寸表的分類，請將 requires_size_chart 設為 true，並填寫 size_chart_rows。
    5. 撰寫蝦皮 SEO 標題與分段清楚的繁體中文商品描述。
    """
    contents.append(research_prompt)

    response = client.models.generate_content(
        model=MODEL_ID,
        contents=contents,
        config=types.GenerateContentConfig(
            tools=[types.Tool(google_search=types.GoogleSearch())],
            response_mime_type="application/json",
            response_schema=ShopeeListingSchema,
            temperature=0.2,
        ),
    )
    return ShopeeListingSchema.model_validate_json(response.text)


def run_pipeline(image_dir: str, output_dir: str, user_notes: Dict[str, str] = None):
    user_notes = user_notes or {}
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    print("🔍 [Step 1] 正在分析照片並進行多商品自動分群與銘牌辨識...")
    grouping_result = step1_group_and_extract(image_dir, user_notes)
    print(f"✅ 分群完成，共辨識出 {len(grouping_result.groups)} 件獨立商品。")

    for group in grouping_result.groups:
        print(f"\n🌐 [Step 2] 正在聯網調查商品 [{group.group_id}] ({group.detected_brand} {group.detected_model})...")
        combined_notes = " / ".join([user_notes.get(f, "") for f in group.image_filenames if f in user_notes])
        listing_data = step2_research_and_build_json(group, image_dir, combined_notes)

        item_out_dir = Path(output_dir) / group.group_id
        item_out_dir.mkdir(parents=True, exist_ok=True)

        if listing_data.requires_size_chart and listing_data.size_chart_rows:
            chart_path = str(item_out_dir / "size_chart.png")
            generate_size_chart_image(
                rows=listing_data.size_chart_rows,
                output_path=chart_path,
                title=f"{listing_data.shopee_title[:18]} 尺寸表"
            )
            print(f"📏 已自動生成尺寸表圖片：{chart_path}")

        json_path = item_out_dir / "listing.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(listing_data.model_dump(), f, ensure_ascii=False, indent=2)
        print(f"💾 已輸出蝦皮上架結構化資料：{json_path}")


if __name__ == "__main__":
    sample_notes = {
        "IMG_001.jpg": "功能正常，38mm，可加水但沒用過蒸氣功能",
        "IMG_003.jpg": "灰色毛巾底飯店中童拖鞋，全新，適合腳長20公分以內"
    }
    run_pipeline(
        image_dir="./input_photos",
        output_dir="./output_listings",
        user_notes=sample_notes
    )
