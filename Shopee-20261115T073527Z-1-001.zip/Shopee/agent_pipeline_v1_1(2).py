# agent_pipeline.py (v1.1 - 修正 Search Grounding 與 Structured Output 相容性、手機原圖縮圖與 60 字標題驗證)
import os
import json
from pathlib import Path
from typing import Dict, List
from PIL import Image, ImageOps
from google import genai
from google.genai import types

from models import BatchGroupingResult, ImageGroup, ShopeeListingSchema
from chart_generator import generate_size_chart_image

MODEL_ID = "gemini-2.5-flash"


def get_client() -> genai.Client:
    """延遲初始化 Client，避免在未設定環境變數時 import 直接崩潰"""
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise EnvironmentError("請先設定環境變數 GEMINI_API_KEY")
    return genai.Client(api_key=api_key)


def load_and_resize_image(img_path: str, max_side: int = 1600) -> Image.Image:
    """自動修正手機照片 EXIF 旋轉方向，並將長邊縮圖至 1600px 內以節省 Token 與避免 Payload 過大"""
    img = Image.open(img_path)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    img.thumbnail((max_side, max_side), Image.Resampling.LANCZOS)
    return img


def step1_group_and_extract(client: genai.Client, image_dir: str, user_notes: Dict[str, str]) -> BatchGroupingResult:
    """
    第一階段：將混雜的多張商品照片自動歸類分群，並進行銘牌/書背 OCR（型號、ISBN、BSMI、定價貼紙、外觀特徵）
    """
    contents = []
    valid_files = sorted([
        f for f in os.listdir(image_dir)
        if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
    ])

    if not valid_files:
        raise ValueError(f"在 {image_dir} 中找不到任何圖片檔案。")

    for fname in valid_files:
        img_path = os.path.join(image_dir, fname)
        img = load_and_resize_image(img_path)
        note = user_notes.get(fname, "無特別備註")
        contents.append(f"【圖片檔名: {fname} | 賣家備註: {note}】")
        contents.append(img)

    prompt = """
    你是一位專業的台灣電商上架視覺分析 Agent。
    請檢視以上所有上傳的照片與檔名，執行以下任務：
    1. 視覺分群：判斷哪些照片屬於「同一個商品」（例如正面照、背面照、機身貼紙照、書本封面與封底照），將它們歸類為同一個 group_id（如 item_01, item_02）。
    2. 銘牌、書背與標籤提取：
       - 仔細讀取照片中的品牌/出版社（如 世一、TESCOM）、商品名稱、型號/貨號（如 CF10041、IPM850）。
       - 若為書籍，請讀取國際標準書號 ISBN（如 978-986-429-216-5）。
       - 檢查是否有印出台灣 BSMI 商檢字號（通常為 R、M、T 開頭加上 5 碼數字，例如童書/玩具常見 M63042，家電常見 R31310）。
       - 檢查是否有定價或特價貼紙（例如「特價399元」、「定價：720元」）。
    3. 結合賣家備註，詳細記錄外觀特徵與新舊狀況。
    """
    contents.append(prompt)

    response = client.models.generate_content(
        model=MODEL_ID,
        contents=contents,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=BatchGroupingResult,
            temperature=0.1,
        ),
    )
    result = BatchGroupingResult.model_validate_json(response.text)

    # 防呆過濾：確保回傳的檔名皆實際存在於資料夾中
    valid_set = set(valid_files)
    for g in result.groups:
        g.image_filenames = [f for f in g.image_filenames if f in valid_set]
    return result


def step2_research_and_build_json(
    client: genai.Client,
    group: ImageGroup,
    image_dir: str,
    general_note: str = ""
) -> ShopeeListingSchema:
    """
    第二階段（拆分為 2A 聯網檢索 + 2B 結構化輸出，避免 Search Grounding 與 JSON Schema 衝突）：
    - Step 2A: 使用 Google Search 查詢台灣全新價、二手行情價、官方長寬高規格、適用年齡與 BSMI。
    - Step 2B: 將檢索報告與視覺特徵轉換為嚴格符合 ShopeeListingSchema（含 60 字元標題限制）的 JSON。
    """
    images: List[Image.Image] = [
        load_and_resize_image(os.path.join(image_dir, fname))
        for fname in group.image_filenames
    ]

    # Step 2A: 聯網檢索（純文字報告，不綁定 response_schema 以確保 Google Search 100% 穩定觸發）
    search_prompt = f"""
    請根據這組商品的照片與第一階段視覺提取結果，使用 Google Search 搜尋台灣市場資料，整理出一份詳盡的調查報告：

    【第一階段提取資訊】
    - 辨識品牌/出版社：{group.detected_brand}
    - 辨識型號/貨號：{group.detected_model}
    - 辨識 ISBN：{group.detected_isbn}
    - 照片上的 BSMI：{group.detected_bsmi_from_photo}
    - 照片上的定價/特價：{group.detected_original_price}
    - 外觀與特徵：{group.visual_features}
    - 賣家補充說明：{general_note}

    【請聯網查詢並列出以下具體數據】
    1. 台灣全新品價格與官方定價（台幣）：搜尋誠品、三民、博客來、Momo、Coupang 酷澎或官方商城的定價與目前全新品特價。
    2. 台灣二手市場行情價（台幣）：搜尋蝦皮拍賣、旋轉拍賣、露天拍賣或讀冊 TAAZE 上同款商品「二手 / 九成新」的實際掛牌價格區間（請排除低於新品 1 折的異常標價）。
    3. 官方尺寸與重量：查詢該商品（或 ISBN）的實際長、寬、高（cm）與重量（kg），以及頁數/裝訂方式（若為書籍）。
    4. 適用年齡與合規字號：確認適用年齡範圍，以及 BSMI 檢驗字號（若照片已拍到 {group.detected_bsmi_from_photo} 則直接沿用，若未拍到請聯網搜尋）。
    """

    search_response = client.models.generate_content(
        model=MODEL_ID,
        contents=[*images, search_prompt],
        config=types.GenerateContentConfig(
            tools=[types.Tool(google_search=types.GoogleSearch())],
            temperature=0.2,
        ),
    )
    research_report = search_response.text

    # Step 2B: 結構化 JSON 轉換（強制遵守 ShopeeListingSchema 與 60 字元標題上限）
    format_prompt = f"""
    請根據以下「第一階段視覺資訊」與「第二階段聯網調查報告」，轉換為蝦皮賣家中心的上架 JSON 格式：

    【第一階段視覺資訊】
    {group.model_dump_json(indent=2)}

    【第二階段聯網調查報告】
    {research_report}

    【填表嚴格規範】
    1. shopee_title（商品名稱）：嚴格限制在 60 個字元以內！請包含「品牌/出版社 + 商品名稱 + 核心特色/系列 + 規格/新舊狀態」。
    2. shopee_description（商品描述）：請使用繁體中文，分段列出【商品特色】、【實品書況/物況】、【詳細規格（含尺寸、ISBN、BSMI、適用年齡）】与【寄送須知】。
    3. 物流材積判斷：台灣超商取貨限制為「最長邊 <= 45cm，長+寬+高 <= 105cm，重量 <= 5kg」，請據此設定 can_ship_convenience_store。
    4. 定價建議：請根據全新品特價與二手行情區間，提供快速出清價、一般行情價、近全新高價三個合理台幣整數。
    """

    structured_response = client.models.generate_content(
        model=MODEL_ID,
        contents=format_prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ShopeeListingSchema,
            temperature=0.1,
        ),
    )
    return ShopeeListingSchema.model_validate_json(structured_response.text)


def run_pipeline(image_dir: str, output_dir: str, user_notes: Dict[str, str] = None):
    user_notes = user_notes or {}
    client = get_client()
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    print("🔍 [Step 1] 正在分析照片並進行多商品自動分群與銘牌/書背 OCR...")
    grouping_result = step1_group_and_extract(client, image_dir, user_notes)
    print(f"✅ 分群完成，共辨識出 {len(grouping_result.groups)} 件獨立商品。")

    for group in grouping_result.groups:
        print(f"\n🌐 [Step 2] 正在聯網調查商品 [{group.group_id}] ({group.detected_brand} {group.detected_model or group.detected_isbn})...")
        combined_notes = " / ".join([user_notes.get(f, "") for f in group.image_filenames if f in user_notes])
        listing_data = step2_research_and_build_json(client, group, image_dir, combined_notes)

        item_out_dir = Path(output_dir) / group.group_id
        item_out_dir.mkdir(parents=True, exist_ok=True)

        if listing_data.requires_size_chart and listing_data.size_chart_rows:
            chart_path = str(item_out_dir / "size_chart.png")
            generate_size_chart_image(
                rows=listing_data.size_chart_rows,
                output_path=chart_path,
                title=f"{listing_data.shopee_title[:18]} 尺寸表"
            )
            print(f"📏 已自動生成尺寸表圖片：{chart_path}")

        json_path = item_out_dir / "listing.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(listing_data.model_dump(), f, ensure_ascii=False, indent=2)
        print(f"💾 已輸出蝦皮上架結構化資料（標題長度 {len(listing_data.shopee_title)}/60 字元）：{json_path}")


if __name__ == "__main__":
    sample_notes = {
        "book_front.jpg": "二手童書，書況良好，翻翻頁完整",
    }
    run_pipeline(
        image_dir="./input_photos",
        output_dir="./output_listings",
        user_notes=sample_notes
    )
