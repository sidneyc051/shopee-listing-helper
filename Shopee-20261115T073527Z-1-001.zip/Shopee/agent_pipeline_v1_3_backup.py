# agent_pipeline_v1_1.py (v1.3 修正版：升級 gemini-3-flash + 支援單一商品強制合併模式與強化跨角度分群)
import os
import json
from pathlib import Path
from typing import Dict, List, Optional
from PIL import Image, ImageOps
from google import genai
from google.genai import types

from models_v1_1 import BatchGroupingResult, ImageGroup, ShopeeListingSchema
from chart_generator_v1_1 import generate_size_chart_image

# 預設優先使用最新模型，若帳號支援度不同則自動 fallback
CANDIDATE_MODELS = [
    "gemini-3-flash-preview",
    "gemini-3-flash",
    "gemini-2.5-pro",
    "gemini-2.0-flash",
]
MAX_IMAGE_SIDE = 1600

_client: Optional[genai.Client] = None
_active_model: Optional[str] = None


def get_client() -> genai.Client:
    """Lazy Initialization：在實際呼叫 API 時才初始化 Client"""
    global _client
    if _client is None:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise EnvironmentError("找不到環境變數 GEMINI_API_KEY，請先設定後再執行。")
        _client = genai.Client(api_key=api_key)
    return _client


def generate_with_fallback(contents, config: types.GenerateContentConfig, preferred_model: Optional[str] = None):
    """自動嘗試可用模型，徹底解決 404 NOT_FOUND 模型停用問題"""
    global _active_model
    client = get_client()

    models_to_try = []
    if preferred_model:
        models_to_try.append(preferred_model)
    if _active_model and _active_model not in models_to_try:
        models_to_try.append(_active_model)
    for m in CANDIDATE_MODELS:
        if m not in models_to_try:
            models_to_try.append(m)

    last_err = None
    for model_name in models_to_try:
        try:
            resp = client.models.generate_content(
                model=model_name,
                contents=contents,
                config=config,
            )
            _active_model = model_name
            return resp
        except Exception as e:
            err_str = str(e)
            if "404" in err_str or "NOT_FOUND" in err_str or "no longer available" in err_str:
                print(f"⚠️ 模型 {model_name} 無法使用，自動切換下一個候選模型...")
                last_err = e
                continue
            raise e
    raise RuntimeError(f"所有候選模型皆無法呼叫，最後錯誤：{last_err}")


def load_and_preprocess_image(img_path: str) -> Image.Image:
    """讀取手機照片，自動校正 EXIF 旋轉方向並等比例縮圖至 1600px 以內"""
    img = Image.open(img_path)
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("RGB", "L"):
        img = img.convert("RGB")
    img.thumbnail((MAX_IMAGE_SIDE, MAX_IMAGE_SIDE), Image.Resampling.LANCZOS)
    return img


def step1_group_and_extract(
    image_dir: str,
    user_notes: Dict[str, str],
    target_files: Optional[List[str]] = None,
    force_single_item: bool = False,
    preferred_model: Optional[str] = None,
) -> BatchGroupingResult:
    """
    第一階段：將商品照片歸類分群並進行銘牌/版權頁 OCR
    - target_files: 若有指定，只分析本次勾選/上傳的照片（避免舊照片混入）
    - force_single_item: 若為 True，強制將所有照片視為同一個商品 (item_01) 的不同角度
    """
    all_dir_files = sorted([
        f for f in os.listdir(image_dir)
        if f.lower().endswith((".jpg", ".jpeg", ".png", ".webp"))
    ])
    valid_files = [f for f in all_dir_files if (not target_files or f in target_files)]

    if not valid_files:
        raise ValueError(f"在 {image_dir} 中找不到任何符合條件的圖片檔案。")

    contents = []
    for fname in valid_files:
        img_path = os.path.join(image_dir, fname)
        img = load_and_preprocess_image(img_path)
        note = user_notes.get(fname, "無特別備註")
        contents.append(f"【圖片檔名: {fname} | 賣家備註: {note}】")
        contents.append(img)

    if force_single_item:
        grouping_rule = """
        1. 【強制單一商品模式】：以上所有照片（包含正面、背面、側面、內頁、標籤特寫、尺寸測量或不同角度）100% 全部屬於「同一個商品」！
           請務必只建立唯一一個群組 `item_01`，並將所有圖片檔名都放進 `item_01` 的 `image_filenames` 清單中，絕對不可拆成多個 group_id。
        """
    else:
        grouping_rule = """
        1. 【智慧跨角度合併分群】：請注意！賣家拍攝同一個商品時，通常會連續拍攝多張不同角度的照片（例如：正面外觀、背面、側面、內頁翻拍、底部標籤、機身銘牌特寫、吊牌、外盒或瑕疵特寫）。
           - 只要照片中的物品在材質、顏色、主題或連號檔名（如 IMG_4581, IMG_4582, IMG_4583）上屬於同一件商品的不同視角或局部特寫，請務必「合併歸類在同一個 group_id」！
           - 寧可合併也不要過度拆分，只有當明顯出現「完全不同種類或不同款式的另一件商品」時，才建立新的 group_id（如 item_02）。
        """

    prompt = f"""
    你是一位專業的台灣電商上架視覺分析 Agent。
    請檢視以上所有上傳的照片與檔名，執行以下任務：
    {grouping_rule}
    2. 銘牌、條碼與版權頁提取：
       - 仔細讀取照片中的品牌或出版社（如 TESCOM、世一文化）。
       - 讀取型號、貨號或書籍 ISBN（如 IPM850、CF10041、ISBN 978-986-429-216-5）。
       - 讀取台灣 BSMI 檢驗字號（R、M、T、D 開頭加上 5 碼數字，如 M63042）以及批號（如 1705005）。
       - 讀取照片上印製的「原定價」（如 定價：720元）、「特價貼紙」（如 特價 399元）以及「適用年齡」（如 3歲以上）。
    3. 結合賣家備註，詳細記錄外觀特徵與新舊狀況。
    """
    contents.append(prompt)

    response = generate_with_fallback(
        contents=contents,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=BatchGroupingResult,
            temperature=0.1,
        ),
        preferred_model=preferred_model,
    )
    result = BatchGroupingResult.model_validate_json(response.text)

    valid_set = set(valid_files)
    for group in result.groups:
        group.image_filenames = [f for f in group.image_filenames if f in valid_set]

    # 若開啟強制單一商品模式，雙重保險確保所有圖片合併為 item_01
    if force_single_item and result.groups:
        first_group = result.groups[0]
        first_group.group_id = "item_01"
        first_group.image_filenames = valid_files
        result.groups = [first_group]

    return result


def step2_research_and_build_json(
    group: ImageGroup,
    image_dir: str,
    general_note: str = "",
    preferred_model: Optional[str] = None,
) -> ShopeeListingSchema:
    """第二階段：2A 聯網檢索 + 2B 結構化輸出"""
    images: List[Image.Image] = [
        load_and_preprocess_image(os.path.join(image_dir, fname))
        for fname in group.image_filenames
    ]

    search_prompt = f"""
    請根據這組商品的照片與第一階段視覺提取結果，使用 Google Search 搜尋台灣市場資料：

    【第一階段提取資訊】
    - 群組編號：{group.group_id}
    - 圖片清單：{group.image_filenames}
    - 辨識品牌/出版社：{group.detected_brand}
    - 辨識型號/ISBN/貨號：{group.detected_model}
    - 照片上的 BSMI：{group.detected_bsmi_from_photo} (批號：{group.detected_bsmi_batch_number})
    - 外觀與特徵：{group.visual_features}
    - 賣家補充說明：{general_note}

    請聯網查詢並詳細列出以下台灣市場真實數據：
    1. 官方實體規格：長、寬、高/厚度 (cm)、重量 (kg)、頁數或材質，並驗證是否可超商取貨（最長邊<=45cm，三邊和<=105cm，重量<=5kg）。
    2. 全新與二手價格行情（台幣）：
       - 原定價與目前主流電商（誠品、三民、Momo、博客來、酷澎）全新品售價。
       - 蝦皮拍賣、旋轉拍賣、讀冊生活、露天二手書/二手賣場的實際二手掛牌價區間（排除低於 1 折的配件或故障品）。
    3. BSMI 檢驗字號與適用年齡：若照片已有拍到則直接確認，若未拍到請搜尋標檢局或電商頁面補齊。
    """
    search_response = generate_with_fallback(
        contents=[*images, search_prompt],
        config=types.GenerateContentConfig(
            tools=[types.Tool(google_search=types.GoogleSearch())],
            temperature=0.2,
        ),
        preferred_model=preferred_model,
    )
    research_report = search_response.text

    format_prompt = f"""
    請將以下【第一階段視覺提取資訊】與【第二階段聯網調查報告】整合，輸出為符合蝦皮賣家中心規範的 JSON 格式。

    【重要規則】
    1. `shopee_title` 蝦皮商品標題必須嚴格控制在 **60 個字元以內**（包含中英文、數字、括號與空格），將最重要的品牌/出版社、商品名稱、型號/系列、新舊狀態放在最前面。
    2. `group_id` 請填寫 `{group.group_id}`，`image_filenames` 請原封不動填入 `{json.dumps(group.image_filenames)}`。
    3. 若照片已拍到 BSMI 字號（如 `{group.detected_bsmi_from_photo}`）與批號（如 `{group.detected_bsmi_batch_number}`），請務必填入 `bsmi_number` 與 `bsmi_batch_number`。

    【第一階段視覺提取資訊】
    {group.model_dump_json(indent=2)}

    【第二階段聯網調查報告】
    {research_report}
    """
    structured_response = generate_with_fallback(
        contents=format_prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema=ShopeeListingSchema,
            temperature=0.1,
        ),
        preferred_model=preferred_model,
    )
    return ShopeeListingSchema.model_validate_json(structured_response.text)


def run_pipeline(
    image_dir: str,
    output_dir: str,
    user_notes: Dict[str, str] = None,
    target_files: Optional[List[str]] = None,
    force_single_item: bool = False,
    preferred_model: Optional[str] = None,
):
    user_notes = user_notes or {}
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    print("🔍 [Step 1] 正在分析照片並進行商品分群與銘牌/版權頁辨識...")
    grouping_result = step1_group_and_extract(
        image_dir=image_dir,
        user_notes=user_notes,
        target_files=target_files,
        force_single_item=force_single_item,
        preferred_model=preferred_model,
    )
    print(f"✅ 分群完成，共辨識出 {len(grouping_result.groups)} 件獨立商品。")

    for group in grouping_result.groups:
        print(f"\n🌐 [Step 2] 正在聯網調查商品 [{group.group_id}] ({group.detected_brand} {group.detected_model})...")
        combined_notes = " / ".join([user_notes.get(f, "") for f in group.image_filenames if f in user_notes])
        listing_data = step2_research_and_build_json(
            group=group,
            image_dir=image_dir,
            general_note=combined_notes,
            preferred_model=preferred_model,
        )

        item_out_dir = Path(output_dir) / group.group_id
        item_out_dir.mkdir(parents=True, exist_ok=True)

        if listing_data.requires_size_chart and listing_data.size_chart_rows:
            chart_path = str(item_out_dir / "size_chart.png")
            generate_size_chart_image(
                rows=listing_data.size_chart_rows,
                output_path=chart_path,
                title=f"{listing_data.shopee_title[:18]} 尺寸表"
            )
            print(f"📏 已自動生成尺寸表圖片：{chart_path}")

        json_path = item_out_dir / "listing.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(listing_data.model_dump(), f, ensure_ascii=False, indent=2)
        print(f"💾 已輸出蝦皮上架結構化資料（標題長度 {len(listing_data.shopee_title)} 字元）：{json_path}")
