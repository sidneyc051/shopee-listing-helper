# app.py - 蝦皮賣家上架小工具 Web UI (支援手機上傳與電腦審核)
import os
import json
from pathlib import Path
from typing import Dict
import streamlit as st
from PIL import Image

from agent_pipeline_v1_1 import run_pipeline

INPUT_DIR = Path("./input_photos")
OUTPUT_DIR = Path("./output_listings")
INPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

st.set_page_config(
    page_title="蝦皮 AI 快速上架助手",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.title("🛍️ 蝦皮 AI 智慧上架小工具 v1.1")
st.caption("手機拍照上傳 ➔ AI 自動分群、聯網查價、查 BSMI 與生成尺寸表 ➔ 一鍵匯入蝦皮賣家中心")

# 側邊欄：API Key 與環境設定
with st.sidebar:
    st.header("⚙️ 系統設定")
    api_key_input = st.text_input(
        "Gemini API Key",
        value=os.environ.get("GEMINI_API_KEY", ""),
        type="password",
        help="請輸入你的 GEMINI_API_KEY"
    )
    if api_key_input:
        os.environ["GEMINI_API_KEY"] = api_key_input

    if st.button("🗑️ 清空 input_photos 待處理照片"):
        for f in INPUT_DIR.glob("*"):
            if f.is_file():
                f.unlink()
        st.success("已清空待處理照片！")
        st.rerun()

tab_upload, tab_review = st.tabs(["📸 1. 手機拍照上傳與 AI 分析", "📋 2. 審核修改與蝦皮一鍵複製"])

# ==================== Tab 1: 上傳照片與觸發 Agent ====================
with tab_upload:
    st.subheader("步驟 1：選取商品照片（可一次混傳多件商品的正反面、規格貼紙）")
    uploaded_files = st.file_uploader(
        "點擊選取相簿照片或直接開啟手機相機拍攝",
        type=["jpg", "jpeg", "png", "webp"],
        accept_multiple_files=True,
    )

    user_notes: Dict[str, str] = {}

    if uploaded_files:
        st.info(f"已選取 {len(uploaded_files)} 張照片，可於下方補充簡短備註（如：九成新、盒裝完整、尺寸）：")
        cols = st.columns(min(3, len(uploaded_files)))
        for idx, ufile in enumerate(uploaded_files):
            save_path = INPUT_DIR / ufile.name
            with open(save_path, "wb") as f:
                f.write(ufile.getbuffer())

            col = cols[idx % len(cols)]
            with col:
                st.image(ufile, caption=ufile.name, use_container_width=True)
                note = st.text_input(
                    f"備註 ({ufile.name})",
                    key=f"note_{ufile.name}",
                    placeholder="例如：二手保存良好、38mm、適合18cm內"
                )
                if note.strip():
                    user_notes[ufile.name] = note.strip()

    # 顯示目前已存在於 input_photos 的檔案
    existing_photos = sorted([
        p.name for p in INPUT_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")
    ])
    st.write(f"📂 目前雲端 `input_photos` 資料夾共有 **{len(existing_photos)}** 張照片：{', '.join(existing_photos)}")

    if st.button("🚀 啟動 AI 自動分群、聯網查價與產生蝦皮欄位", type="primary", use_container_width=True):
        if not os.environ.get("GEMINI_API_KEY"):
            st.error("請先於左側邊欄輸入 GEMINI_API_KEY！")
        elif not existing_photos:
            st.warning("請先上傳至少一張商品照片！")
        else:
            with st.spinner("🔍 AI Agent 正在進行視覺分群、銘牌 OCR 與全網比價調查，請稍候約 20~40 秒..."):
                try:
                    run_pipeline(
                        image_dir=str(INPUT_DIR),
                        output_dir=str(OUTPUT_DIR),
                        user_notes=user_notes
                    )
                    st.success("🎉 分析完成！請切換至上方「📋 2. 審核修改與蝦皮一鍵複製」分頁檢視結果。")
                except Exception as e:
                    st.error(f"執行過程發生錯誤：{e}")

# ==================== Tab 2: 審核、微調與匯出 JSON ====================
with tab_review:
    item_dirs = sorted([d for d in OUTPUT_DIR.iterdir() if d.is_dir()])

    if not item_dirs:
        st.info("目前 `output_listings` 尚無已分析的商品資料，請先於第一分頁上傳照片並啟動分析。")
    else:
        selected_group = st.selectbox(
            "選擇要審核的商品編號",
            options=[d.name for d in item_dirs],
            format_func=lambda x: f"📦 商品群組：{x}"
        )

        item_dir = OUTPUT_DIR / selected_group
        json_path = item_dir / "listing.json"
        chart_path = item_dir / "size_chart.png"

        if json_path.exists():
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            col_left, col_right = st.columns([1, 1.4])

            with col_left:
                st.markdown("#### 🖼️ 商品照片與尺寸表")
                img_files = data.get("image_filenames", [])
                for fname in img_files:
                    img_p = INPUT_DIR / fname
                    if img_p.exists():
                        st.image(str(img_p), caption=fname, use_container_width=True)

                if chart_path.exists():
                    st.markdown("##### 📏 自動生成的蝦皮尺寸表圖片")
                    st.image(str(chart_path), caption="size_chart.png", use_container_width=True)
                    with open(chart_path, "rb") as cf:
                        st.download_button(
                            "⬇️ 下載尺寸表圖片 (size_chart.png)",
                            data=cf,
                            file_name=f"{selected_group}_size_chart.png",
                            mime="image/png",
                            use_container_width=True
                        )

                # 比價行情卡片
                pricing = data.get("pricing", {})
                st.markdown("#### 💰 AI 全網比價行情摘要")
                st.info(
                    f"**原定價：** NT$ {pricing.get('original_list_price_twd') or '無'} ｜ "
                    f"**新品市價：** NT$ {pricing.get('new_market_price_twd') or '無'}\n\n"
                    f"**二手行情區間：** NT$ {pricing.get('used_price_min_twd') or '?'} ~ {pricing.get('used_price_max_twd') or '?'}\n\n"
                    f"📝 {pricing.get('pricing_reference_summary', '')}"
                )

            with col_right:
                st.markdown("#### ✏️ 蝦皮賣家中心欄位審核與快速複製")

                # 標題編輯（即時顯示字元數，限制 60 字元）
                current_title = data.get("shopee_title", "")
                new_title = st.text_input(
                    f"商品名稱（目前 {len(current_title)} / 60 字元）",
                    value=current_title,
                    max_chars=60
                )

                # 三檔位價格快速選擇
                p_quick = pricing.get("suggested_quick_sale_price", 100)
                p_std = pricing.get("suggested_standard_price", 150)
                p_high = pricing.get("suggested_high_price", 200)

                price_tier = st.radio(
                    "選擇欲上架的定價檔位",
                    options=[
                        f"🔥 快速出清價 (${p_quick})",
                        f"✅ 一般行情價 (${p_std})",
                        f"💎 近全新高價 (${p_high})",
                        "🛠️ 自訂售價"
                    ],
                    index=1,
                    horizontal=True
                )

                if "快速出清價" in price_tier:
                    selected_price = p_quick
                elif "一般行情價" in price_tier:
                    selected_price = p_std
                elif "近全新高價" in price_tier:
                    selected_price = p_high
                else:
                    selected_price = st.number_input("輸入自訂售價 (NT$)", min_value=1, value=int(p_std))

                data["selected_listing_price_twd"] = int(selected_price)

                # 商品描述編輯
                new_desc = st.text_area(
                    "商品描述（上限 3000 字元）",
                    value=data.get("shopee_description", ""),
                    height=260
                )

                c1, c2, c3 = st.columns(3)
                with c1:
                    new_cond = st.selectbox(
                        "商品保存狀況",
                        options=["二手", "全新"],
                        index=0 if data.get("condition") == "二手" else 1
                    )
                    new_brand = st.text_input("品牌 / 出版社", value=data.get("brand", ""))
                with c2:
                    new_bsmi = st.text_input("BSMI 檢驗字號", value=data.get("bsmi_number") or "")
                    new_batch = st.text_input("BSMI 批號", value=data.get("bsmi_batch_number") or "")
                with c3:
                    new_isbn = st.text_input("國際條碼 (GTIN / ISBN)", value=data.get("isbn_or_barcode") or "")
                    dims = data.get("dimensions", {})
                    new_weight = st.number_input(
                        "包裹重量 (kg)",
                        min_value=0.01,
                        max_value=30.0,
                        value=float(dims.get("weight_kg", 0.5)),
                        step=0.05
                    )

                st.caption(f"📂 建議蝦皮分類路徑：`{' > '.join(data.get('suggested_category_path', []))}`")

                # 儲存修改按鈕
                if st.button("💾 儲存修改至 listing.json", use_container_width=True):
                    data["shopee_title"] = new_title[:60]
                    data["shopee_description"] = new_desc
                    data["condition"] = new_cond
                    data["brand"] = new_brand
                    data["bsmi_number"] = new_bsmi or None
                    data["bsmi_batch_number"] = new_batch or None
                    data["isbn_or_barcode"] = new_isbn or None
                    data["dimensions"]["weight_kg"] = new_weight
                    data["pricing"]["suggested_standard_price"] = int(selected_price)

                    with open(json_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    st.success("✅ 已成功更新 listing.json！")

                st.divider()
                st.markdown("##### ⚡ 手機／電腦一鍵複製與外掛匯入區")
                st.markdown("1. **手機 App 直接貼上**：點選下方程式碼區塊右上角的「複製」圖示即可貼入蝦皮 App。")
                st.code(new_title, language=None)
                st.code(new_desc, language=None)

                st.markdown("2. **電腦版 Chrome 外掛一鍵自動填表**：下載此 JSON 或複製下方完整 JSON 貼入瀏覽器外掛。")
                json_str = json.dumps(data, ensure_ascii=False, indent=2)
                st.download_button(
                    "⬇️ 下載 listing.json（供 Chrome 自動填表外掛載入）",
                    data=json_str.encode("utf-8"),
                    file_name=f"{selected_group}_listing.json",
                    mime="application/json",
                    use_container_width=True
                )
                with st.expander("展開檢視 / 複製完整 listing.json"):
                    st.code(json_str, language="json")
