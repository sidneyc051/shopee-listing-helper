# app.py (v1.2 iOS 單手大按鈕極速複製版 + 支援電腦端審核)
import os
import json
from pathlib import Path
from typing import Dict
import streamlit as st
import streamlit.components.v1 as components

from agent_pipeline_v1_1 import run_pipeline

INPUT_DIR = Path("./input_photos")
OUTPUT_DIR = Path("./output_listings")
INPUT_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

st.set_page_config(
    page_title="蝦皮 AI 快速上架助手",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="collapsed",
)


def render_ios_copy_card(data: dict, selected_price: int):
    """
    渲染專為 iPhone Safari 設計的單手拇指大顆一鍵複製面板（支援 iOS Clipboard API 與自動視覺回饋）
    """
    dims = data.get("dimensions", {})
    cat_str = " > ".join(data.get("suggested_category_path", []))

    fields = [
        {"id": "cp_title", "label": "1️⃣ 複製【商品名稱】(60字內)", "value": data.get("shopee_title", ""), "primary": True},
        {"id": "cp_desc", "label": "2️⃣ 複製【商品描述】(完整排版文案)", "value": data.get("shopee_description", ""), "primary": True},
        {"id": "cp_price", "label": f"3️⃣ 複製【售價】(${selected_price})", "value": str(selected_price), "primary": False},
        {"id": "cp_weight", "label": f"4️⃣ 複製【重量】({dims.get('weight_kg', 0.5)} kg)", "value": str(dims.get("weight_kg", 0.5)), "primary": False},
        {"id": "cp_isbn", "label": f"5️⃣ 複製【國際條碼 GTIN/ISBN】({data.get('isbn_or_barcode') or '無'})", "value": str(data.get("isbn_or_barcode") or ""), "primary": False},
        {"id": "cp_bsmi", "label": f"6️⃣ 複製【BSMI 字號】({data.get('bsmi_number') or '無'})", "value": str(data.get("bsmi_number") or ""), "primary": False},
        {"id": "cp_batch", "label": f"7️⃣ 複製【BSMI 批號】({data.get('bsmi_batch_number') or '無'})", "value": str(data.get("bsmi_batch_number") or ""), "primary": False},
        {"id": "cp_brand", "label": f"8️⃣ 複製【品牌/出版社】({data.get('brand') or '無'})", "value": str(data.get("brand") or ""), "primary": False},
    ]

    fields_json = json.dumps(fields, ensure_ascii=False)

    html_code = f"""
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
      <style>
        body {{
          font-family: -apple-system, BlinkMacSystemFont, "PingFang TC", "Microsoft JhengHei", sans-serif;
          margin: 0;
          padding: 4px;
          background: transparent;
        }}
        .ios-panel {{
          background: #ffffff;
          border: 2px solid #ee4d2d;
          border-radius: 16px;
          padding: 14px;
          box-shadow: 0 6px 18px rgba(238, 77, 45, 0.12);
        }}
        .panel-header {{
          font-size: 16px;
          font-weight: 700;
          color: #ee4d2d;
          margin-bottom: 6px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }}
        .cat-badge {{
          background: #fff7ed;
          border: 1px solid #fed7aa;
          color: #9a3412;
          border-radius: 10px;
          padding: 8px 10px;
          font-size: 13px;
          margin-bottom: 12px;
          line-height: 1.4;
        }}
        .btn-grid {{
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }}
        .copy-btn {{
          appearance: none;
          -webkit-tap-highlight-color: transparent;
          border: 1.5px solid #cbd5e1;
          background: #f8fafc;
          color: #1e293b;
          border-radius: 12px;
          padding: 14px 12px;
          font-size: 14px;
          font-weight: 600;
          text-align: left;
          cursor: pointer;
          transition: all 0.15s ease;
          display: flex;
          align-items: center;
          justify-content: space-between;
          box-shadow: 0 2px 4px rgba(0,0,0,0.04);
        }}
        .copy-btn.full-width {{
          grid-column: span 2;
          background: #fff1f0;
          border-color: #ffa39e;
          color: #cf1322;
          font-size: 15px;
          padding: 16px 14px;
        }}
        .copy-btn:active {{
          transform: scale(0.97);
        }}
        .copy-btn.copied {{
          background: #16a34a !important;
          border-color: #15803d !important;
          color: #ffffff !important;
        }}
        .shopee-launch {{
          margin-top: 12px;
          display: block;
          text-align: center;
          background: #ee4d2d;
          color: #ffffff;
          text-decoration: none;
          font-weight: 700;
          font-size: 15px;
          padding: 14px;
          border-radius: 12px;
        }}
      </style>
    </head>
    <body>
      <div class="ios-panel">
        <div class="panel-header">
          <span>📱 iPhone 單手極速複製面板</span>
          <span style="font-size:12px;color:#64748b;font-weight:normal;">點一下即複製</span>
        </div>
        <div class="cat-badge">
          📂 <b>蝦皮分類路徑：</b>{cat_str or "請手動選擇"}<br/>
          📦 <b>保存狀況：</b>{data.get("condition", "二手")} ｜ <b>尺寸：</b>{dims.get("length_cm", 0)}x{dims.get("width_cm", 0)}x{dims.get("height_cm", 0)} cm
        </div>
        <div class="btn-grid" id="btnContainer"></div>
        <a class="shopee-launch" href="shopee://" target="_blank">
          🚀 點此切換打開「蝦皮 App」直接貼上
        </a>
      </div>

      <script>
        const fields = {fields_json};
        const container = document.getElementById("btnContainer");

        function fallbackCopyText(text) {{
          const ta = document.createElement("textarea");
          ta.value = text;
          ta.style.position = "fixed";
          ta.style.opacity = "0";
          document.body.appendChild(ta);
          ta.focus();
          ta.select();
          document.execCommand("copy");
          document.body.removeChild(ta);
        }}

        async function copyToClipboard(text, btnEl, originalLabel) {{
          try {{
            if (navigator.clipboard && window.isSecureContext) {{
              await navigator.clipboard.writeText(text);
            }} else {{
              fallbackCopyText(text);
            }}
          }} catch (e) {{
            fallbackCopyText(text);
          }}
          btnEl.classList.add("copied");
          btnEl.innerHTML = "<span>✅ 已複製到 iPhone 剪貼簿！</span><span>📋</span>";
          setTimeout(() => {{
            btnEl.classList.remove("copied");
            btnEl.innerHTML = `<span>${{originalLabel}}</span><span>📋</span>`;
          }}, 1400);
        }}

        fields.forEach(item => {{
          const btn = document.createElement("button");
          btn.className = "copy-btn" + (item.primary ? " full-width" : "");
          btn.innerHTML = `<span>${{item.label}}</span><span>📋</span>`;
          btn.onclick = () => copyToClipboard(item.value || "", btn, item.label);
          container.appendChild(btn);
        }});
      </script>
    </body>
    </html>
    """
    components.html(html_code, height=470, scrolling=False)


st.title("🛍️ 蝦皮 AI 智慧上架小工具 v1.2")
st.caption("iPhone 隨手拍 ➔ AI 自動分群、查價、查 BSMI 與生尺寸表 ➔ 單手一鍵複製貼入蝦皮 App")

with st.sidebar:
    st.header("⚙️ 系統設定")
    api_key_input = st.text_input(
        "Gemini API Key",
        value=os.environ.get("GEMINI_API_KEY", ""),
        type="password",
        help="請輸入你的 GEMINI_API_KEY"
    )
    if api_key_input:
        os.environ["GEMINI_API_KEY"] = api_key_input

    if st.button("🗑️ 清空 input_photos 待處理照片"):
        for f in INPUT_DIR.glob("*"):
            if f.is_file():
                f.unlink()
        st.success("已清空待處理照片！")
        st.rerun()

tab_upload, tab_review = st.tabs(["📸 1. iPhone 拍照上傳", "📱 2. 單手一鍵複製上架"])

# ==================== Tab 1: 上傳照片與觸發 Agent ====================
with tab_upload:
    st.subheader("步驟 1：選取商品照片（支援直接開 iPhone 相機或從相簿多選）")
    uploaded_files = st.file_uploader(
        "點擊選取相簿照片或直接拍攝（可一次混傳多件不同商品的正反面、規格貼紙）",
        type=["jpg", "jpeg", "png", "webp"],
        accept_multiple_files=True,
    )

    user_notes: Dict[str, str] = {}

    if uploaded_files:
        st.info(f"已選取 {len(uploaded_files)} 張照片，可於下方補充簡短備註（可留空）：")
        cols = st.columns(min(3, len(uploaded_files)))
        for idx, ufile in enumerate(uploaded_files):
            save_path = INPUT_DIR / ufile.name
            with open(save_path, "wb") as f:
                f.write(ufile.getbuffer())

            col = cols[idx % len(cols)]
            with col:
                st.image(ufile, caption=ufile.name, use_container_width=True)
                note = st.text_input(
                    f"備註 ({ufile.name})",
                    key=f"note_{ufile.name}",
                    placeholder="例如：二手保存良好、38mm、適合18cm內"
                )
                if note.strip():
                    user_notes[ufile.name] = note.strip()

    existing_photos = sorted([
        p.name for p in INPUT_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")
    ])
    st.write(f"📂 目前 `input_photos` 資料夾共有 **{len(existing_photos)}** 張照片：{', '.join(existing_photos)}")

    if st.button("🚀 啟動 AI 自動分群、聯網查價與產生蝦皮欄位", type="primary", use_container_width=True):
        if not os.environ.get("GEMINI_API_KEY"):
            st.error("請先點開左上角「>」側邊欄輸入 GEMINI_API_KEY！")
        elif not existing_photos:
            st.warning("請先上傳至少一張商品照片！")
        else:
            with st.spinner("🔍 AI Agent 正在進行視覺分群、銘牌 OCR 與全網比價調查，請稍候約 20~40 秒..."):
                try:
                    run_pipeline(
                        image_dir=str(INPUT_DIR),
                        output_dir=str(OUTPUT_DIR),
                        user_notes=user_notes
                    )
                    st.success("🎉 分析完成！請點選上方「📱 2. 單手一鍵複製上架」分頁開始複製。")
                except Exception as e:
                    st.error(f"執行過程發生錯誤：{e}")

# ==================== Tab 2: iPhone 單手極速複製與審核 ====================
with tab_review:
    item_dirs = sorted([d for d in OUTPUT_DIR.iterdir() if d.is_dir()])

    if not item_dirs:
        st.info("目前 `output_listings` 尚無已分析的商品資料，請先於第一分頁上傳照片並啟動分析。")
    else:
        selected_group = st.selectbox(
            "選擇要上架的商品編號",
            options=[d.name for d in item_dirs],
            format_func=lambda x: f"📦 待上架商品：{x}"
        )

        item_dir = OUTPUT_DIR / selected_group
        json_path = item_dir / "listing.json"
        chart_path = item_dir / "size_chart.png"

        if json_path.exists():
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            pricing = data.get("pricing", {})
            p_quick = pricing.get("suggested_quick_sale_price", 100)
            p_std = pricing.get("suggested_standard_price", 150)
            p_high = pricing.get("suggested_high_price", 200)

            st.markdown("#### 💰 步驟 1：點選要賣的價格檔位")
            st.caption(
                f"📊 原定價：${pricing.get('original_list_price_twd') or '無'} ｜ "
                f"新品市價：${pricing.get('new_market_price_twd') or '無'} ｜ "
                f"二手行情：${pricing.get('used_price_min_twd') or '?'}~${pricing.get('used_price_max_twd') or '?'}"
            )

            price_tier = st.radio(
                "定價檔位選擇",
                options=[
                    f"🔥 快速出清 (${p_quick})",
                    f"✅ 一般行情 (${p_std})",
                    f"💎 近全新 (${p_high})",
                    "🛠️ 自訂"
                ],
                index=1,
                horizontal=True,
                label_visibility="collapsed"
            )

            if "快速出清" in price_tier:
                selected_price = p_quick
            elif "一般行情" in price_tier:
                selected_price = p_std
            elif "近全新" in price_tier:
                selected_price = p_high
            else:
                selected_price = st.number_input("輸入自訂售價 (NT$)", min_value=1, value=int(p_std))

            data["selected_listing_price_twd"] = int(selected_price)

            st.markdown("#### 📱 步驟 2：iPhone 單手點選複製（點完直接切去蝦皮 App 貼上）")
            render_ios_copy_card(data, int(selected_price))

            if chart_path.exists():
                st.markdown("#### 📏 步驟 3：長按圖片儲存尺寸表（供蝦皮服飾/鞋類上傳）")
                st.image(str(chart_path), caption="iPhone 可直接長按上方圖片選擇「加入照片」", use_container_width=True)

            with st.expander("✏️ 需要微調文字或欄位內容？（點此展開編輯）"):
                current_title = data.get("shopee_title", "")
                new_title = st.text_input(
                    f"商品名稱（目前 {len(current_title)} / 60 字元）",
                    value=current_title,
                    max_chars=60
                )
                new_desc = st.text_area(
                    "商品描述（上限 3000 字元）",
                    value=data.get("shopee_description", ""),
                    height=220
                )
                c1, c2 = st.columns(2)
                with c1:
                    new_cond = st.selectbox(
                        "保存狀況",
                        options=["二手", "全新"],
                        index=0 if data.get("condition") == "二手" else 1
                    )
                    new_brand = st.text_input("品牌 / 出版社", value=data.get("brand", ""))
                    new_isbn = st.text_input("國際條碼 (GTIN / ISBN)", value=data.get("isbn_or_barcode") or "")
                with c2:
                    new_bsmi = st.text_input("BSMI 檢驗字號", value=data.get("bsmi_number") or "")
                    new_batch = st.text_input("BSMI 批號", value=data.get("bsmi_batch_number") or "")
                    dims = data.get("dimensions", {})
                    new_weight = st.number_input(
                        "包裹重量 (kg)",
                        min_value=0.01,
                        max_value=30.0,
                        value=float(dims.get("weight_kg", 0.5)),
                        step=0.05
                    )

                if st.button("💾 儲存修改並更新上方複製按鈕", type="primary", use_container_width=True):
                    data["shopee_title"] = new_title[:60]
                    data["shopee_description"] = new_desc
                    data["condition"] = new_cond
                    data["brand"] = new_brand
                    data["bsmi_number"] = new_bsmi or None
                    data["bsmi_batch_number"] = new_batch or None
                    data["isbn_or_barcode"] = new_isbn or None
                    data["dimensions"]["weight_kg"] = new_weight
                    data["pricing"]["suggested_standard_price"] = int(selected_price)

                    with open(json_path, "w", encoding="utf-8") as f:
                        json.dump(data, f, ensure_ascii=False, indent=2)
                    st.success("✅ 已更新！上方單手複製按鈕已同步為最新內容。")
                    st.rerun()
