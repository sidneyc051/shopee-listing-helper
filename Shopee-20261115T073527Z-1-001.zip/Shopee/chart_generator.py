# chart_generator.py
from PIL import Image, ImageDraw, ImageFont
from typing import List
from models import SizeChartRow

def generate_size_chart_image(rows: List[SizeChartRow], output_path: str, title: str = "商品尺寸參考表") -> str:
    width, height = 800, 140 + (len(rows) + 1) * 60
    img = Image.new("RGB", (width, height), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)

    # 載入支援繁體中文的系統字體（支援 Windows 微軟正黑體、Mac PingFang、或 Linux/Colab 思源黑體）
    font_candidates_bold = [
        "msjhbd.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    ]
    font_candidates_regular = [
        "msjh.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    ]

    font_title = ImageFont.load_default()
    for path in font_candidates_bold:
        try:
            font_title = ImageFont.truetype(path, 28)
            break
        except IOError:
            continue

    font_cell = ImageFont.load_default()
    for path in font_candidates_regular:
        try:
            font_cell = ImageFont.truetype(path, 20)
            break
        except IOError:
            continue

    # 繪製標題
    draw.text((40, 30), title, fill=(30, 30, 30), font=font_title)

    # 表格欄位座標與表頭
    col_x = [40, 190, 400, 580, 760]
    headers = ["尺碼", "規格測量 1", "規格測量 2", "建議年齡 / 範圍"]
    start_y = 90
    row_h = 60

    # 繪製表頭底色
    draw.rectangle([col_x[0], start_y, col_x[-1], start_y + row_h], fill=(240, 242, 245))

    # 繪製表頭文字
    for i, header_text in enumerate(headers):
        draw.text((col_x[i] + 12, start_y + 18), header_text, fill=(0, 0, 0), font=font_cell)

    # 繪製資料列
    for row_idx, row in enumerate(rows):
        y = start_y + (row_idx + 1) * row_h
        cells = [row.size_label, row.measurement_1, row.measurement_2, row.recommended_age_or_height]
        for col_idx, cell_text in enumerate(cells):
            draw.text((col_x[col_idx] + 12, y + 18), str(cell_text), fill=(50, 50, 50), font=font_cell)

    # 繪製格線
    total_rows = len(rows) + 1
    for r in range(total_rows + 1):
        y = start_y + r * row_h
        draw.line([(col_x[0], y), (col_x[-1], y)], fill=(200, 200, 200), width=2)
    for x in col_x:
        draw.line([(x, start_y), (x, start_y + total_rows * row_h)], fill=(200, 200, 200), width=2)

    img.save(output_path)
    return output_path
