# build_extension.py - 自動確保 Chrome Extension 檔案皆為純文字格式（避免 Google Drive 將 HTML 轉為 Google Docs）
from pathlib import Path

POPUP_HTML_CONTENT = """<!DOCTYPE html>
<html lang="zh-Hant">
<head>
  <meta charset="UTF-8" />
  <title>蝦皮 AI 自動填表助手</title>
  <style>
    body { width: 350px; font-family: "Microsoft JhengHei", -apple-system, sans-serif; padding: 12px 14px; margin: 0; background: #f8fafc; color: #1e293b; }
    h3 { margin: 0 0 8px 0; font-size: 16px; color: #ee4d2d; }
    .field-group { margin-bottom: 10px; }
    label { display: block; font-size: 12px; font-weight: 600; margin-bottom: 4px; color: #475569; }
    input[type="file"], select, textarea { width: 100%; box-sizing: border-box; font-size: 12px; padding: 6px; border: 1px solid #cbd5e1; border-radius: 6px; background: #fff; }
    textarea { height: 110px; font-family: monospace; resize: vertical; }
    button { width: 100%; padding: 10px; background: #ee4d2d; color: #ffffff; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; margin-top: 4px; }
    button:hover { background: #d73211; }
    #status { margin-top: 10px; font-size: 12px; padding: 8px; border-radius: 6px; display: none; white-space: pre-line; }
    .ok { display: block !important; background: #dcfce7; color: #166534; }
    .err { display: block !important; background: #fee2e2; color: #991b1b; }
  </style>
</head>
<body>
  <h3>🛍️ 蝦皮 AI 一鍵填表助手 v1.1</h3>
  <div class="field-group">
    <label>1. 選擇 listing.json 檔案（或直接貼於下方）：</label>
    <input type="file" id="jsonFile" accept=".json" />
  </div>
  <div class="field-group">
    <label>2. 選擇要填入的價格檔位：</label>
    <select id="priceMode">
      <option value="standard" selected>✅ 建議一般行情價 (Standard)</option>
      <option value="quick">🔥 建議快速出清價 (Quick Sale)</option>
      <option value="high">💎 建議近全新高價 (High)</option>
    </select>
  </div>
  <div class="field-group">
    <label>3. JSON 內容預覽 / 貼上區：</label>
    <textarea id="jsonText" placeholder="請選擇 listing.json 檔案，或從 Streamlit 網頁直接複製 JSON 貼在這裡..."></textarea>
  </div>
  <button id="fillBtn">⚡ 一鍵自動填入蝦皮新增商品頁</button>
  <div id="status"></div>
  <script src="popup.js"></script>
</body>
</html>
"""

if __name__ == "__main__":
    out_path = Path(__file__).parent / "popup.html"
    out_path.write_text(POPUP_HTML_CONTENT, encoding="utf-8")
    print(f"✅ 已生成純文字版 {out_path}")
