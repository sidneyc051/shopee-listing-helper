// content.js - 蝦皮賣家中心 (seller.shopee.tw) Vue/React 相容自動填表腳本
(function () {
  /**
   * 觸發原生 Input/Textarea value setter，確保蝦皮賣家中心的 Vue/React 雙向綁定能偵測到數值變更
   */
  function setNativeInputValue(el, value) {
    if (!el || value === undefined || value === null) return false;
    el.focus();
    const proto =
      el.tagName === "TEXTAREA"
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
    const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (nativeSetter) {
      nativeSetter.call(el, String(value));
    } else {
      el.value = String(value);
    }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
    return true;
  }

  /**
   * 依據標籤文字或 placeholder 尋找對應的 input / textarea
   */
  function findInputByKeywords(keywords, tag = "input") {
    // 1. 先找 placeholder 匹配的欄位
    const allInputs = Array.from(document.querySelectorAll(tag));
    for (const kw of keywords) {
      const match = allInputs.find(
        (el) =>
          (el.placeholder && el.placeholder.includes(kw)) ||
          (el.getAttribute("aria-label") && el.getAttribute("aria-label").includes(kw))
      );
      if (match) return match;
    }

    // 2. 找表單列 (form-item / edit-row) 內含關鍵字標籤的鄰近輸入框
    const labelContainers = Array.from(
      document.querySelectorAll(
        ".eds-form-item, .product-edit-form-item, [class*='form-item'], [class*='edit-row'], label"
      )
    );
    for (const kw of keywords) {
      for (const container of labelContainers) {
        const text = (container.innerText || "").trim();
        if (text.startsWith(kw) || text.includes(kw)) {
          const inputEl = container.querySelector(tag);
          if (inputEl) return inputEl;
        }
      }
    }
    return null;
  }

  /**
   * 顯示右上角浮動小幫手面板（提供一鍵複製 BSMI / 批號 / 建議分類 / 尺寸與快速重填）
   */
  function showFloatingHelperPanel(data, chosenPrice, filledFields) {
    const oldPanel = document.getElementById("shopee-ai-helper-panel");
    if (oldPanel) oldPanel.remove();

    const panel = document.createElement("div");
    panel.id = "shopee-ai-helper-panel";
    panel.style.cssText = `
      position: fixed;
      top: 76px;
      right: 20px;
      width: 310px;
      background: #ffffff;
      border: 2px solid #ee4d2d;
      border-radius: 10px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.18);
      padding: 14px;
      z-index: 999999;
      font-family: "Microsoft JhengHei", sans-serif;
      font-size: 12px;
      color: #1e293b;
    `;

    const catPath = (data.suggested_category_path || []).join(" > ");
    const dims = data.dimensions || {};

    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong style="color:#ee4d2d;font-size:14px;">🛍️ AI 上架小幫手 (${data.group_id || "item"})</strong>
        <button id="close-ai-panel" style="border:none;background:transparent;cursor:pointer;font-size:16px;">✕</button>
      </div>
      <div style="background:#f8fafc;padding:8px;border-radius:6px;line-height:1.6;margin-bottom:8px;">
        <div>📂 <b>建議分類：</b>${catPath || "請手動選擇"}</div>
        <div>💰 <b>選定售價：</b>NT$ ${chosenPrice} (保存狀況：${data.condition || "二手"})</div>
        <div>📦 <b>尺寸重量：</b>${dims.length_cm || 0} x ${dims.width_cm || 0} x ${dims.height_cm || 0} cm / ${dims.weight_kg || 0.5} kg</div>
        <div>🛡️ <b>BSMI 字號：</b>${data.bsmi_number || "無"} ${data.bsmi_batch_number ? "(批號: " + data.bsmi_batch_number + ")" : ""}</div>
        <div>🔖 <b>ISBN/條碼：</b>${data.isbn_or_barcode || "無"}</div>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button id="re-fill-attrs" style="flex:1;padding:6px;background:#ee4d2d;color:#fff;border:none;border-radius:4px;cursor:pointer;font-weight:bold;">
          🔄 選擇分類後補填屬性/BSMI
        </button>
      </div>
    `;

    document.body.appendChild(panel);
    document.getElementById("close-ai-panel").onclick = () => panel.remove();
    document.getElementById("re-fill-attrs").onclick = () => {
      fillAllFields(data, chosenPrice);
    };
  }

  function fillAllFields(data, chosenPrice) {
    const filledFields = [];

    // 1. 商品名稱 (限制 60 字元)
    const titleEl =
      findInputByKeywords(["商品名稱", "輸入商品名稱", "Product Name"], "input") ||
      document.querySelector("input[maxlength='60'], input[maxlength='100']");
    if (titleEl && data.shopee_title) {
      setNativeInputValue(titleEl, data.shopee_title.slice(0, 60));
      filledFields.push("商品名稱");
    }

    // 2. 商品描述 (支援標準 textarea 與富文本 contenteditable)
    const descEl =
      findInputByKeywords(["商品描述", "輸入商品描述", "Description"], "textarea") ||
      document.querySelector(".ql-editor, [contenteditable='true']");
    if (descEl && data.shopee_description) {
      if (descEl.tagName === "TEXTAREA") {
        setNativeInputValue(descEl, data.shopee_description);
      } else {
        descEl.focus();
        descEl.innerText = data.shopee_description;
        descEl.dispatchEvent(new Event("input", { bubbles: true }));
      }
      filledFields.push("商品描述");
    }

    // 3. 價格 (NT$)
    const priceEl = findInputByKeywords(["價格", "售價", "NT$", "輸入價格"], "input");
    if (priceEl && chosenPrice) {
      setNativeInputValue(priceEl, chosenPrice);
      filledFields.push(`價格($${chosenPrice})`);
    }

    // 4. 商品數量 (庫存預設填 1)
    const stockEl = findInputByKeywords(["商品數量", "庫存", "Stock"], "input");
    if (stockEl) {
      setNativeInputValue(stockEl, 1);
      filledFields.push("商品數量(1)");
    }

    // 5. 國際條碼 (GTIN / ISBN)
    if (data.isbn_or_barcode) {
      const gtinEl = findInputByKeywords(["國際條碼", "GTIN", "ISBN", "條碼"], "input");
      if (gtinEl) {
        setNativeInputValue(gtinEl, data.isbn_or_barcode);
        filledFields.push("GTIN/ISBN");
      }
    }

    // 6. 重量与包裹尺寸 (長 / 寬 / 高)
    const dims = data.dimensions || {};
    if (dims.weight_kg) {
      const weightEl = findInputByKeywords(["重量", "Weight", "kg"], "input");
      if (weightEl) {
        setNativeInputValue(weightEl, dims.weight_kg);
        filledFields.push("重量");
      }
    }
    const lenEl = findInputByKeywords(["長", "Length"], "input");
    const widEl = findInputByKeywords(["寬", "Width"], "input");
    const heiEl = findInputByKeywords(["高", "Height"], "input");
    if (lenEl && dims.length_cm) setNativeInputValue(lenEl, Math.ceil(dims.length_cm));
    if (widEl && dims.width_cm) setNativeInputValue(widEl, Math.ceil(dims.width_cm));
    if (heiEl && dims.height_cm) setNativeInputValue(heiEl, Math.ceil(dims.height_cm));

    // 7. BSMI 檢驗字號與批號 (選擇分類展開屬性後可填入)
    if (data.bsmi_number) {
      const bsmiEl = findInputByKeywords(["BSMI", "商檢字號", "檢驗字號", "認證"], "input");
      if (bsmiEl) {
        setNativeInputValue(bsmiEl, data.bsmi_number);
        filledFields.push("BSMI字號");
      }
    }
    if (data.bsmi_batch_number) {
      const batchEl = findInputByKeywords(["批號", "Batch"], "input");
      if (batchEl) {
        setNativeInputValue(batchEl, data.bsmi_batch_number);
        filledFields.push("BSMI批號");
      }
    }

    return filledFields;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === "FILL_SHOPEE_PRODUCT") {
      try {
        const data = msg.payload || {};
        const pricing = data.pricing || {};
        let chosenPrice =
          data.selected_listing_price_twd || pricing.suggested_standard_price || 199;
        if (msg.priceMode === "quick" && pricing.suggested_quick_sale_price) {
          chosenPrice = pricing.suggested_quick_sale_price;
        } else if (msg.priceMode === "high" && pricing.suggested_high_price) {
          chosenPrice = pricing.suggested_high_price;
        }

        const filledFields = fillAllFields(data, chosenPrice);
        showFloatingHelperPanel(data, chosenPrice, filledFields);
        sendResponse({ success: true, filledFields });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    }
    return true;
  });
})();
