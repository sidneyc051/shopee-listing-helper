// popup.js - 處理 listing.json 載入並傳送指令至蝦皮頁面 content.js
document.addEventListener("DOMContentLoaded", async () => {
  const fileInput = document.getElementById("jsonFile");
  const jsonText = document.getElementById("jsonText");
  const priceMode = document.getElementById("priceMode");
  const fillBtn = document.getElementById("fillBtn");
  const statusBox = document.getElementById("status");

  // 載入上次暫存的 JSON
  chrome.storage.local.get(["savedListingJson", "savedPriceMode"], (res) => {
    if (res.savedListingJson) jsonText.value = res.savedListingJson;
    if (res.savedPriceMode) priceMode.value = res.savedPriceMode;
  });

  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      jsonText.value = ev.target.result;
      chrome.storage.local.set({ savedListingJson: ev.target.result });
      showStatus("✅ 已載入檔案：" + file.name, true);
    };
    reader.readAsText(file, "utf-8");
  });

  fillBtn.addEventListener("click", async () => {
    let data;
    try {
      data = JSON.parse(jsonText.value.trim());
    } catch (err) {
      showStatus("❌ JSON 格式解析失敗，請確認內容是否完整！", false);
      return;
    }

    chrome.storage.local.set({
      savedListingJson: jsonText.value.trim(),
      savedPriceMode: priceMode.value,
    });

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url.includes("seller.shopee.tw")) {
      showStatus("⚠️ 請先在目前分頁打開「蝦皮賣家中心 > 新增商品」頁面！", false);
      return;
    }

    chrome.tabs.sendMessage(
      tab.id,
      {
        action: "FILL_SHOPEE_PRODUCT",
        payload: data,
        priceMode: priceMode.value,
      },
      (response) => {
        if (chrome.runtime.lastError) {
          showStatus(
            "⚠️ 無法連線至頁面腳本，請重新整理蝦皮賣家中心網頁後再試一次。",
            false
          );
          return;
        }
        if (response && response.success) {
          showStatus(
            `🎉 自動填表完成！\n已填入欄位：${response.filledFields.join("、")}\n\n📌 提醒：請拖曳上傳商品圖片並點選確認分類與物流開關。`,
            true
          );
        } else {
          showStatus("❌ 填表未完成：" + (response?.error || "未知錯誤"), false);
        }
      }
    );
  });

  function showStatus(msg, isOk) {
    statusBox.textContent = msg;
    statusBox.className = isOk ? "ok" : "err";
  }
});
