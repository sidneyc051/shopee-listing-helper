# models.py
from typing import List, Optional
from pydantic import BaseModel, Field

class ImageGroup(BaseModel):
    group_id: str = Field(description="商品分群編號，例如 item_01")
    image_filenames: List[str] = Field(description="屬於此商品的圖片檔名清單")
    detected_brand: Optional[str] = Field(description="從外觀或標籤辨識出的品牌")
    detected_model: Optional[str] = Field(description="從機身銘牌或外盒辨識出的型號")
    detected_bsmi_from_photo: Optional[str] = Field(description="照片標籤上直接拍到的 BSMI 字號（如 R31234）")
    visual_features: str = Field(description="外觀特徵、顏色、配件與新舊狀況觀察")

class BatchGroupingResult(BaseModel):
    groups: List[ImageGroup]

class DimensionsAndLogistics(BaseModel):
    length_cm: float = Field(description="預估或官方商品長度(公分)")
    width_cm: float = Field(description="預估或官方商品寬度(公分)")
    height_cm: float = Field(description="預估或官方商品高度(公分)")
    weight_kg: float = Field(description="預估或官方商品含包裝重量(公斤)")
    can_ship_convenience_store: bool = Field(
        description="是否符合超商取貨限制（最長邊小於等於45cm，三邊總和小於等於105cm，重量小於等於5kg）"
    )

class PricingAnalysis(BaseModel):
    new_market_price_twd: Optional[int] = Field(description="全新品目前電商或官網參考售價(台幣)")
    used_price_min_twd: Optional[int] = Field(description="二手市場最低行情價(台幣)")
    used_price_max_twd: Optional[int] = Field(description="二手市場最高行情價(台幣)")
    suggested_quick_sale_price: int = Field(description="建議快速出清價（低於二手均價約15%）")
    suggested_standard_price: int = Field(description="建議一般行情售價")
    suggested_high_price: int = Field(description="建議近全新高價")
    pricing_reference_summary: str = Field(description="比價來源與行情簡述")

class SizeChartRow(BaseModel):
    size_label: str = Field(description="尺碼標示，例如 M號、中童、或單一尺寸")
    measurement_1: str = Field(description="關鍵尺寸1，例如 適合腳長 18cm 以內 或 衣長 45cm")
    measurement_2: str = Field(description="關鍵尺寸2，例如 鞋內長 19cm 或 胸寬 38cm")
    recommended_age_or_height: str = Field(description="適用年齡或身高範圍，例如 3-5歲 / 100-110cm")

class ShopeeListingSchema(BaseModel):
    group_id: str
    image_filenames: List[str]
    shopee_title: str = Field(description="蝦皮 SEO 商品標題（60字內，含品牌、型號、核心特色、規格）")
    shopee_description: str = Field(description="完整蝦皮商品描述，含商品特色、實品狀況、詳細規格與寄送須知")
    suggested_category_path: List[str] = Field(description="建議蝦皮分類路徑，例如 ['手機平板與周邊', '美容家電', '電棒捲/離子夾']")
    condition: str = Field(description="全新 或 二手")
    brand: str = Field(description="品牌名稱，無品牌則填 自有品牌 或 無")
    model_number: Optional[str] = Field(description="商品型號")
    applicable_age_range: Optional[str] = Field(description="適用年齡範圍（婦幼、玩具、童裝童鞋必填）")
    requires_bsmi: bool = Field(description="此分類在蝦皮是否通常需要填寫 BSMI 檢驗字號（如家電、3C、玩具）")
    bsmi_number: Optional[str] = Field(description="查到的 BSMI 字號（R/M/T開頭），若無須填寫則為 null")
    requires_size_chart: bool = Field(description="此分類是否屬於服飾、鞋類等需要上傳尺寸表圖片的商品")
    size_chart_rows: Optional[List[SizeChartRow]] = Field(description="若需要尺寸表，提供繪製表格用的列資料")
    dimensions: DimensionsAndLogistics
    pricing: PricingAnalysis
