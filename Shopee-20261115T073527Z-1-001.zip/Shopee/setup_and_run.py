# setup_and_run.py (v1.1 一鍵安裝與執行腳本)
import subprocess
import sys
import os

REQUIRED_PACKAGES = ["google-genai>=1.0.0", "pydantic>=2.0.0", "pillow>=10.0.0"]

def install_dependencies():
    print("📦 正在檢查並安裝必要套件 (google-genai, pydantic, pillow)...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "-U", *REQUIRED_PACKAGES])

if __name__ == "__main__":
    install_dependencies()
    from agent_pipeline_v1_1 import run_pipeline
    run_pipeline(
        image_dir="./input_photos",
        output_dir="./output_listings",
        user_notes={}
    )
