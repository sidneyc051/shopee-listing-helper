# shopee_playwright_filler.py - 使用 Playwright 自動開啟瀏覽器並填入蝦皮新增商品頁面
import json
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

SHOPEE_NEW_PRODUCT_URL = "https://seller.shopee.tw/portal/product/new"
USER_DATA_DIR = "./shopee_browser_profile"  # 保存蝦皮登入狀態，免每次重登


def fill_input_by_placeholder_or_label(page, keywords, value):
    if value is None or value == "":
        return False
    val_str = str(value)

    for kw in keywords:
        # 嘗試以 placeholder 定位
        loc = page.locator(f"input[placeholder*='{kw}'], textarea[placeholder*='{kw}']").first
        if loc.count() > 0 and loc.is_visible():
            loc.click()
            loc.fill(val_str)
            return True

        # 嘗試以表單標籤文字定位
        form_item = page.locator(f".eds-form-item:has-text('{kw}'), [class*='form-item']:has-text('{kw}')").first
        if form_item.count() > 0 and form_item.is_visible():
            inp = form_item.locator("input, textarea").first
            if inp.count() > 0 and inp.is_visible():
                inp.click()
                inp.fill(val_str)
                return True
    return False


def autofill_shopee_from_json(json_path: str, image_dir: str = "./input_photos"):
    listing_file = Path(json_path)
    if not listing_file.exists():
        raise FileNotFoundError(f"找不到指定的 JSON 檔案：{json_path}")

    with open(listing_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    pricing = data.get("pricing", {})
    chosen_price = data.get("selected_listing_price_twd") or pricing.get("suggested_standard_price", 199)
    dims = data.get("dimensions", {})

    print(f"🚀 準備自動填寫商品：{data.get('shopee_title')}")
    print("💡 若首次開啟尚未登入蝦皮賣家中心，請先於彈出的瀏覽器視窗完成登入。")

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=USER_DATA_DIR,
            headless=False,
            viewport={"width": 1440, "height": 900},
        )
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(SHOPEE_NEW_PRODUCT_URL)

        input("👉 請確認瀏覽器已進入「蝦皮賣家中心 > 新增商品」頁面（若需先點選分類也可先點好），按 Enter 鍵開始自動填表...")

        # 1. 自動上傳商品圖片
        img_paths = [
            str(Path(image_dir) / fname)
            for fname in data.get("image_filenames", [])
            if (Path(image_dir) / fname).exists()
        ]
        if img_paths:
            try:
                file_input = page.locator("input[type='file'][accept*='image']").first
                if file_input.count() > 0:
                    file_input.set_input_files(img_paths)
                    print(f"✅ 已自動掛載 {len(img_paths)} 張商品圖片")
            except Exception as e:
                print(f"⚠️ 自動上傳圖片略過（請手動拖曳圖片）：{e}")

        # 2. 填入商品名稱 (限制 60 字元)
        if fill_input_by_placeholder_or_label(page, ["商品名稱", "輸入商品名稱"], data.get("shopee_title", "")[:60]):
            print("✅ 已填入：商品名稱")

        # 3. 填入商品描述
        desc = data.get("shopee_description", "")
        if not fill_input_by_placeholder_or_label(page, ["商品描述", "輸入商品描述"], desc):
            editor = page.locator(".ql-editor, [contenteditable='true']").first
            if editor.count() > 0:
                editor.click()
                editor.fill(desc)
                print("✅ 已填入：商品描述 (富文本編輯器)")
        else:
            print("✅ 已填入：商品描述")

        # 4. 填入價格與商品數量
        if fill_input_by_placeholder_or_label(page, ["價格", "售價", "NT$"], chosen_price):
            print(f"✅ 已填入：價格 (NT$ {chosen_price})")

        if fill_input_by_placeholder_or_label(page, ["商品數量", "庫存"], 1):
            print("✅ 已填入：商品數量 (1)")

        # 5. 填入國際條碼 (GTIN / ISBN)
        if data.get("isbn_or_barcode"):
            if fill_input_by_placeholder_or_label(page, ["國際條碼", "GTIN", "ISBN"], data["isbn_or_barcode"]):
                print(f"✅ 已填入：國際條碼 ({data['isbn_or_barcode']})")

        # 6. 填入重量與長寬高
        if dims.get("weight_kg"):
            fill_input_by_placeholder_or_label(page, ["重量", "Weight"], dims["weight_kg"])
        if dims.get("length_cm"):
            fill_input_by_placeholder_or_label(page, ["長", "Length"], int( round(dims["length_cm"]) ))
            fill_input_by_placeholder_or_label(page, ["寬", "Width"], int( round(dims["width_cm"]) ))
            fill_input_by_placeholder_or_label(page, ["高", "Height"], int( round(dims["height_cm"]) ))
            print("✅ 已填入：重量與包裹尺寸")

        # 7. 填入 BSMI 字號與批號
        if data.get("bsmi_number"):
            if fill_input_by_placeholder_or_label(page, ["BSMI", "商檢", "檢驗字號"], data["bsmi_number"]):
                print(f"✅ 已填入：BSMI 字號 ({data['bsmi_number']})")
        if data.get("bsmi_batch_number"):
            fill_input_by_placeholder_or_label(page, ["批號"], data["bsmi_batch_number"])

        print("\n🎉 自動填表執行完畢！請於瀏覽器視窗檢查後點擊「儲存並上架」。")
        input("按 Enter 鍵關閉瀏覽器視窗...")
        context.close()


if __name__ == "__main__":
    target_json = sys.argv[1] if len(sys.argv) > 1 else "./output_listings/item_01/listing.json"
    autofill_shopee_from_json(target_json)
