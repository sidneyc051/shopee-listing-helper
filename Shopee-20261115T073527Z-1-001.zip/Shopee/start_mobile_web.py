# start_mobile_web.py (v1.6 穩定防 502 版：自動清理舊程序、確認 Port 8501 就緒後才開啟 Cloudflare 隧道，並禁用 CORS/XSRF 阻擋)
import os
import sys
import time
import socket
import subprocess

PORT = 8501


def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def is_port_open(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1.0)
        return s.connect_ex(("127.0.0.1", port)) == 0


def kill_existing_streamlit():
    """清理 Colab 背景殘留的舊 Streamlit 或 cloudflared 程序，避免 Port 衝突導致 502"""
    try:
        subprocess.run(["pkill", "-f", "streamlit"], stderr=subprocess.DEVNULL)
        subprocess.run(["pkill", "-f", "cloudflared"], stderr=subprocess.DEVNULL)
        time.sleep(1)
    except Exception:
        pass


def ensure_packages():
    pkgs = ["streamlit>=1.35.0", "pycloudflared", "qrcode", "google-genai>=1.0.0", "pydantic>=2.0.0", "pillow"]
    print("📦 正在檢查必要套件...")
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-q", *pkgs],
        stderr=subprocess.DEVNULL,
    )


def print_qr_in_terminal(url: str):
    try:
        import qrcode
        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.make(fit=True)
        qr.print_ascii(invert=True)
    except Exception:
        pass


def main():
    ensure_packages()
    kill_existing_streamlit()

    local_ip = get_local_ip()
    lan_url = f"http://{local_ip}:{PORT}"
    log_file = open("streamlit_run.log", "w", encoding="utf-8")

    print("\n🚀 正在啟動 Streamlit 伺服器 (app.py)並等待 Port 8501 就緒...")
    st_proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", str(PORT),
            "--server.address", "127.0.0.1",
            "--server.headless", "true",
            "--server.enableCORS", "false",
            "--server.enableXsrfProtection", "false",
        ],
        stdout=log_file,
        stderr=subprocess.STDOUT,
    )

    # 等待 Streamlit 真正監聽 8501 Port（最多等待 25 秒），徹底避免 502 Bad Gateway
    ready = False
    for i in range(25):
        if is_port_open(PORT):
            ready = True
            print(f"✅ Streamlit 伺服器已於 {i+1} 秒內成功啟動並監聽 Port {PORT}！")
            break
        if st_proc.poll() is not None:
            break
        time.sleep(1)

    if not ready:
        log_file.close()
        print("❌ Streamlit 啟動失敗！錯誤日誌如下：")
        with open("streamlit_run.log", "r", encoding="utf-8") as f:
            print(f.read())
        return

    print("🌐 正在建立跨網路 HTTPS 手機專屬網址 (Cloudflare Quick Tunnel)...")
    try:
        from pycloudflared import try_cloudflare
        tunnel_url = try_cloudflare(port=PORT)
        public_url = tunnel_url.tunnel if hasattr(tunnel_url, "tunnel") else str(tunnel_url)
        print("\n" + "★" * 65)
        print("📱 【iPhone 專屬跨網 HTTPS 網址 (伺服器已就緒，點開不會 502！)】")
        print(f"👉 {public_url}")
        print("★" * 65)
        print("\n📷 直接拿 iPhone 相機掃描下方 QR Code 即可開啟：\n")
        print_qr_in_terminal(public_url)
    except Exception as e:
        print(f"⚠️ 無法自動建立外部 HTTPS 隧道 ({e})，同 Wi-Fi 請使用：{lan_url}")

    print("\n⚠️ 重要提醒：請保持此 Google Colab 分頁在執行狀態（不要按下停止 ⏹️），手機才能持續連線！")
    try:
        st_proc.wait()
    except KeyboardInterrupt:
        print("\n🛑 正在關閉伺服器...")
        st_proc.terminate()


if __name__ == "__main__":
    main()
