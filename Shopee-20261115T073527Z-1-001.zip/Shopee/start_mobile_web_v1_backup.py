# start_mobile_web.py - 一鍵啟動 Streamlit 並自動產生 iPhone 專屬網址 (支援 Wi-Fi 區網與跨網 HTTPS 穿隧)
import os
import re
import sys
import time
import socket
import subprocess

PORT = 8501


def get_local_ip() -> str:
    """取得電腦在 Wi-Fi 區網內的 IP 位址"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def ensure_packages():
    pkgs = ["streamlit>=1.35.0", "pycloudflared", "qrcode", "google-genai>=1.0.0", "pydantic>=2.0.0", "pillow>=10.0.0"]
    print("📦 正在檢查並安裝手機連線所需套件 (streamlit, pycloudflared, qrcode)...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "-U", *pkgs])


def print_qr_in_terminal(url: str):
    """直接在終端機印出可供 iPhone 相機掃描的 QR Code"""
    try:
        import qrcode
        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.make(fit=True)
        qr.print_ascii(invert=True)
    except Exception:
        pass


def main():
    ensure_packages()
    local_ip = get_local_ip()
    lan_url = f"http://{local_ip}:{PORT}"

    print("\n🚀 正在背景啟動 Streamlit 網頁伺服器 (app.py)...")
    st_proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", str(PORT),
            "--server.address", "0.0.0.0",
            "--server.headless", "true",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT,
    )

    time.sleep(2)
    print("\n" + "=" * 65)
    print(f"🏠 【方式 1：同一個 Wi-Fi 下使用】iPhone 請打開：{lan_url}")
    print("=" * 65)

    # 啟動 Cloudflare 免註冊免費 HTTPS 公開隧道 (支援 iPhone 4G/5G 行動網路與 Safari 剪貼簿權限)
    print("🌐 正在產生跨網路 HTTPS 手機專屬網址 (Cloudflare Quick Tunnel)...")
    try:
        from pycloudflared import try_cloudflare
        tunnel_url = try_cloudflare(port=PORT)
        public_url = tunnel_url.tunnel if hasattr(tunnel_url, "tunnel") else str(tunnel_url)
        print("\n" + "★" * 65)
        print(f"📱 【方式 2：iPhone 專屬跨網 HTTPS 網址 (推薦加入主畫面)】")
        print(f"👉 {public_url}")
        print("★" * 65)
        print("\n📷 直接拿 iPhone 相機掃描下方 QR Code 即可開啟：\n")
        print_qr_in_terminal(public_url)
    except Exception as e:
        print(f"⚠️ 無法自動建立外部 HTTPS 隧道 ({e})，請直接使用上方 Wi-Fi 網址：{lan_url}")
        print_qr_in_terminal(lan_url)

    print("\n💡 提示：在 iPhone Safari 打開網址後，點選下方「分享」➔「加入主畫面」，即可像原生 App 一樣隨時使用！")
    print("（按 Ctrl + C 可隨時關閉伺服器）")

    try:
        st_proc.wait()
    except KeyboardInterrupt:
        print("\n🛑 正在關閉伺服器...")
        st_proc.terminate()


if __name__ == "__main__":
    main()
